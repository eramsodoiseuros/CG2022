#include "orbit.h"

void Orbit::setRotateAngle(float x){
    rotateAngle = x;
}
float Orbit::getRotateAngle(){
    return rotateAngle;
}
void  Orbit::setRotateX(float x){
    rotateX = x;
}
float Orbit::getRotateX(){
    return rotateX;
}
void  Orbit::setRotateY(float y) {
    rotateY = y;
}
float Orbit::getRotateY(){
    return rotateY;
}
void  Orbit::setRotateZ(float z){
    rotateZ = z;
}
float Orbit::getRotateZ(){
    return rotateZ;
}
void Orbit::setScaleX(float x){
    scaleX = x;
}
float Orbit::getScaleX(){
    return scaleX;
}
void Orbit::setScaleY(float y){
    scaleY = y;
}
float Orbit::getScaleY(){
    return scaleY;
}
void Orbit::setScaleZ(float z){
    scaleZ = z;
}

float Orbit::getScaleZ(){
    return scaleZ;
}

void  Orbit::setRadX(float x){
    radX = x;
}

float Orbit::getRadX(){
    return radX;
}

void  Orbit::setRadZ(float z){
    radZ = z;
}

float Orbit::getRadZ(){
    return radZ;
}